﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using System.Drawing;
using System.Collections;
using System.Timers;

namespace курсовая_1._3
{
    public static class Active
    {
        public static Bitmap MainImage;
        public static PictureBox picture;
        public static Clipboard buffer;
        public static Selection selection=new Selection() ;
        public static Color color = Color.Black;
        public static Pen pen = new Pen(Active.color);
        public static Stack history=new Stack();
        public static bool paste = false;
    }
    public abstract class CShape
    {
        public int count;
        public virtual void On_MouseDown(object sender, MouseEventArgs e) { }
        public virtual void On_MouseMove(object sender, MouseEventArgs e) { }
        public virtual void On_MouseUp(object sender, MouseEventArgs e) { }
        public abstract CShapeMemento createShapeMemento();
        public  void update(CShapeMemento memento)
        {
            if (memento is ConcretMemento)
            {
                ConcretMemento rectmemento = ((ConcretMemento)memento);
                if (rectmemento.getState() is ConcretState)
                {
                    ConcretState rectstate = ((ConcretState)rectmemento.getState());
                    Graphics grfx = Graphics.FromImage(Active.MainImage);
                    grfx.DrawImage(rectstate.bitmap, rectstate.minX, rectstate.minY);
                    grfx.Dispose();
                    rectstate.bitmap.Dispose();
                    Active.picture.Image = Active.MainImage;
                }
            }
        }
        protected class ConcretState : CState
        {
            public int minX, minY, maxX, maxY;
            public Bitmap bitmap;
            public string name=null;
            public ConcretState()
            {
                minX = 0;
                minY = 0;
                maxX = 0;
                maxY = 0;
            }
            
            ~ConcretState()
            {
                bitmap.Dispose();
            }
        }
        protected class ConcretMemento : CShapeMemento
        {
            private ConcretState _state;
            public override CState getState()
            {
                return _state;
            }
            public override void setState(CState state)
            {
                if (state is ConcretState)
                    _state = ((ConcretState)state);
            }
            public ConcretMemento()
            {
                _state = null;
            }
            public override void restore()
            {
                CRectangle rect = new CRectangle(false);
                rect.update(this);
            }
            public override string getName()
            {
                return _state.name;
            }
        }

    }
    public class CState
    {
        ~CState() { }
    }
     public abstract class CShapeMemento
     {
         public abstract CState getState();
         public abstract void setState(CState state);
         public abstract void restore();
         public abstract string getName();
     }


    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
