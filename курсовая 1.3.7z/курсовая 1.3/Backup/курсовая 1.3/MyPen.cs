﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace курсовая_1._3
{
    public class MyPen : CShape
    {
        private static bool dodraw = false;
        private int X, Y, bigX,bigY,smallX,smallY;
        public MyPen()
        { }

        public override CShapeMemento createShapeMemento()
        {
            CShapeMemento memento = new ConcretMemento();
            ConcretState state = new ConcretState();
            state.maxX = bigX+3;
            state.maxY = bigY+3;
            state.minX = smallX-3;
            state.minY = smallY-3;
            state.bitmap = new Bitmap(state.maxX - state.minX, state.maxY - state.minY);
            state.name = "Pen";
            Graphics grfx = Graphics.FromImage(state.bitmap);
            grfx.DrawImage(Active.MainImage, 0, 0, new Rectangle(state.minX, state.minY, state.maxX - state.minX, state.maxY - state.minY), GraphicsUnit.Pixel);
            memento.setState(state);
            grfx.Dispose();
            return memento;
        }
        
        public override void On_MouseDown(object sender, MouseEventArgs e)
        {
            count = 0;
            dodraw = true;
            X = e.X;
            Y = e.Y;
        }
        public override void On_MouseMove(object sender, MouseEventArgs e)
        {
            if (dodraw&&count==5)
            {
                if (X >= e.X && Y >= e.Y) { bigX = X; bigY = Y; smallX = e.X; smallY = e.Y; }
                if (X >= e.X && Y < e.Y) { bigX = X; bigY = e.Y; smallX = e.X; smallY = Y; }
                if (X < e.X && Y >= e.Y) { bigX = e.X; bigY = Y; smallX = X; smallY = e.Y; }
                if (X < e.X && Y < e.Y) { bigX = e.X; bigY = e.Y; smallX = X; smallY = Y; }
                CShapeMemento memento = this.createShapeMemento();
                Active.history.Push(memento);
                Graphics grfx = Graphics.FromImage(Active.MainImage);
                grfx.DrawLine(Active.pen, X, Y, e.X, e.Y);
                X = e.X;
                Y = e.Y;
                grfx.Dispose();
                count = 0;
               ((PictureBox)sender).Image = Active.MainImage;
                
            }
            count++;
        }
        public override void On_MouseUp(object sender, MouseEventArgs e)
        {
            dodraw = false;
            ((PictureBox)sender).Image = Active.MainImage;
        }
       
     

    }
}
