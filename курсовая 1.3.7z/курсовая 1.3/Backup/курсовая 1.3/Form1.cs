﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace курсовая_1._3
{
    public partial class Form1 : Form
    {
        CShape shape=null;
        public Form1()
        {
            InitializeComponent();
            Active.picture = pictureBox1;

        }
        #region Handler
        void AddHandler(CShape shape)
        {
            pictureBox1.MouseDown += new MouseEventHandler(shape.On_MouseDown);
            pictureBox1.MouseMove += new MouseEventHandler(shape.On_MouseMove);
            pictureBox1.MouseUp += new MouseEventHandler(shape.On_MouseUp);


        }
        void RemoveHandler(CShape shape)
        {
            pictureBox1.MouseDown -= new MouseEventHandler(shape.On_MouseDown);
            pictureBox1.MouseMove -= new MouseEventHandler(shape.On_MouseMove);
            pictureBox1.MouseUp -= new MouseEventHandler(shape.On_MouseUp);
        }
        #endregion

        #region Action

        private void Form1_Load(object sender, EventArgs e)
        {
            Active.MainImage = new Bitmap(pictureBox1.ClientSize.Width, pictureBox1.ClientSize.Height);
            Graphics grfx = Graphics.FromImage(Active.MainImage);
            grfx.FillRectangle(Brushes.White, 0, 0, pictureBox1.ClientSize.Width, pictureBox1.ClientSize.Height);
            Active.selection.Set_Parametries(pictureBox1);
        }
         private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                DialogResult res = MessageBox.Show("Вы действительно хотите покинуть приложение?", "Внимание!", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (res == DialogResult.Yes)
                {
                    DialogResult res1 = MessageBox.Show("Сохранить?", "Внимание!", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (res1 == DialogResult.Yes) saveToolStripMenuItem.PerformClick();
                    Application.Exit();
                }
                else e.Cancel = true;
            }
         }
        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Active.MainImage != null)
            {
                DialogResult res = MessageBox.Show("Сохранить изображение", "Внимание!", MessageBoxButtons.YesNoCancel,MessageBoxIcon.Question);
                if (res==DialogResult.Cancel) {return;}
                if (res == DialogResult.Yes) saveToolStripMenuItem.PerformClick();
                Active.MainImage.Dispose();
            }
            if (openFileDialog1.ShowDialog() == DialogResult.OK && openFileDialog1.FileName.Length > 0)
            {
                String filename = openFileDialog1.FileName;
                Active.MainImage = new Bitmap(filename);
                pictureBox1.Image = Active.MainImage;
                pictureBox1.Invalidate();
            }
        }
        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Active.MainImage != null)
            {
                DialogResult res = MessageBox.Show("Сохранить изображение", "Внимание!", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
                if (res == DialogResult.Cancel) return;
                if (res == DialogResult.Yes) saveToolStripMenuItem.PerformClick();
            }
            Graphics grfx = Graphics.FromImage(Active.MainImage);
            grfx.FillRectangle(Brushes.White, 0, 0, pictureBox1.ClientSize.Width, pictureBox1.ClientSize.Height);
            Active.selection.Set_Parametries(pictureBox1);
            Active.history.Clear();
            Active.picture.Refresh();
        }
        private void copyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Active.selection.copy();
        }

        private void cutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Active.selection.cut();     
        }

    

        private void deleteToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Active.selection.delete();

        }

        private void pasteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Active.selection.paste();
           
        }

        private void toolStripButton8_Click(object sender, EventArgs e)//selection
        {
            if (shape != null) RemoveHandler(shape);
            shape = Active.selection;
            AddHandler(Active.selection);
            Width_of_line.Visible = false;
            groupBox2.Visible = false;
        }  


        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (saveFileDialog1.ShowDialog() == DialogResult.OK && saveFileDialog1.FileName.Length > 0)
            {
                Active.MainImage.Save(saveFileDialog1.FileName);
            }
        }
        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

#endregion

        #region Shape
        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            if (shape != null) RemoveHandler(shape);
            shape = new CRectangle(true);
            AddHandler(shape);
            Width_of_line.Visible = false;
            groupBox2.Visible = false;
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            if (shape != null) RemoveHandler(shape);
            shape = new CCircle(true);
            AddHandler(shape);
            Width_of_line.Visible = true;
            groupBox2.Visible = false;
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            if (shape != null) RemoveHandler(shape);
            shape = new CRectangle(false);
            AddHandler(shape);
            Width_of_line.Visible = true;
            groupBox2.Visible = false;
            
            

        }

        private void toolStripButton6_Click(object sender, EventArgs e)
        {
            if (shape != null) RemoveHandler(shape);
            shape = new CCircle(false);
            AddHandler(shape);
            Width_of_line.Visible = true;
            groupBox2.Visible = false;
        }

        private void toolStripButton7_Click(object sender, EventArgs e)
        {
            if (shape != null) RemoveHandler(shape);
            shape = new CLine();
            AddHandler(shape);
            Width_of_line.Visible = true;
            groupBox2.Visible = false;
        }
        #endregion

        #region Pen
        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            if (shape != null) RemoveHandler(shape);
            shape = new MyPen();
            AddHandler(shape);
            Width_of_line.Visible = true;
            groupBox2.Visible = false;

        }
        private void button1_Click(object sender, EventArgs e)
        {
            Active.pen.Width = 1;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Active.pen.Width = 2;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Active.pen.Width = 3;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Active.pen.Width = 4;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Active.pen.Width = 5;
        }
        #endregion        

        #region Rubber
        private void toolStripButton2_Click_1(object sender, EventArgs e)
        {
            Width_of_line.Visible = false;
            groupBox2.Visible = true;
            if (shape != null) RemoveHandler(shape);
            shape = new Rubber();
            AddHandler(shape);
        }
        private void button8_Click(object sender, EventArgs e)
        {
            if (shape is Rubber) ((Rubber)shape).Set_size_form(3);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (shape is Rubber) ((Rubber)shape).Set_size_form(6);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (shape is Rubber) ((Rubber)shape).Set_size_form(10);
        }
        #endregion  

        #region Undo
        private void button9_Click(object sender, EventArgs e)
        {
            if (Active.history.Count != 0)
            {
                CShapeMemento memento = ((CShapeMemento)Active.history.Pop());
                if (memento.getName() != "Pen" && memento.getName() != "Rubber")
                {
                    memento.restore();
                    return;
                }
                if (memento.getName() == "Pen")
                while (memento.getName() == "Pen"&&Active.history.Count != 0)
                {
                    memento.restore();
                    memento = ((CShapeMemento)Active.history.Pop());
                    
                    
                }

                if (memento.getName()=="Rubber")
                while (true)
                {
                    if (memento.getName() == "Rubber"&&Active.history.Count != 0)
                    {
                        memento.restore();
                        memento = ((CShapeMemento)Active.history.Pop());
                        
                    }
                    else return;
                }
                
               
                
            }
           pictureBox1.Image = Active.MainImage;
        }
        private void undoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Undo.PerformClick();
        }
        #endregion

        #region Palette
        private void paletteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                Active.color = colorDialog1.Color;
                Active.pen.Color = colorDialog1.Color;
            }


        }
        private void toolStripButton1_Click_1(object sender, EventArgs e)//red
        {
            Active.color = Color.Red;
            Active.pen.Color = Color.Red;
        }
       

        private void toolStripButton2_Click(object sender, EventArgs e)//green
        {
            Active.color = toolStripButton2.BackColor;
            Active.pen.Color = toolStripButton2.BackColor;
        }

        private void toolStripButton3_Click_1(object sender, EventArgs e)//yellow
        {
            Active.color = toolStripButton3.BackColor;
            Active.pen.Color = toolStripButton3.BackColor;
        }

        private void toolStripButton4_Click_1(object sender, EventArgs e)//brown
        {
            Active.color = toolStripButton4.BackColor;
            Active.pen.Color = toolStripButton4.BackColor;
        }

        private void toolStripButton5_Click_1(object sender, EventArgs e)//maroon
        {
            Active.color = toolStripButton5.BackColor;
            Active.pen.Color = toolStripButton5.BackColor;
        }

        private void toolStripButton6_Click_1(object sender, EventArgs e)//Fuchsia
        {
            Active.color = toolStripButton6.BackColor;
            Active.pen.Color = toolStripButton6.BackColor;
        }

        private void toolStripButton7_Click_1(object sender, EventArgs e)//purple
        {
            Active.color = toolStripButton7.BackColor;
            Active.pen.Color = toolStripButton7.BackColor;
        }

        private void toolStripButton8_Click_1(object sender, EventArgs e)//blue
        {
            Active.color = toolStripButton8.BackColor;
            Active.pen.Color = toolStripButton8.BackColor;
        }

        private void toolStripButton9_Click(object sender, EventArgs e)//black
        {
            Active.color = toolStripButton9.BackColor;
            Active.pen.Color = toolStripButton9.BackColor;
        }

        #endregion

       

       

       
        }

        
    }


