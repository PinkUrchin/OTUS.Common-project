﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace курсовая_1._3
{
    public class Selection : CShape
    {
        private static Bitmap selected;
        private static PictureBox picture = new PictureBox();
        private static bool dodraw = false;
        private static bool dodrdr = false;
        private static int X, Y;
        public Selection()
        {
        }
        public void Set_Parametries(PictureBox parent)
        {
            picture.Parent = parent;
            picture.BackColor = Color.Transparent;
            picture.SizeMode = PictureBoxSizeMode.Normal;
            picture.BorderStyle = BorderStyle.FixedSingle;
            picture.Left = 0;
            picture.Top = 0;
            picture.Width = 0;
            picture.Height = 0;
            picture.Visible = false;
            picture.MouseDown += new MouseEventHandler(picture_MouseDown);
            picture.MouseMove += new MouseEventHandler(picture_MouseMove);
            picture.MouseUp += new MouseEventHandler(picture_MouseUp);
        }
        public override CShapeMemento createShapeMemento()
        {
            ConcretMemento memento = new ConcretMemento();
            ConcretState state = new ConcretState();
            state.bitmap = selected;
            state.minX = picture.Left;
            state.minY = picture.Top;
            state.maxX = picture.Right;
            state.maxY = picture.Bottom;
            memento.setState(state);
            return memento;
        }
        
        public override void On_MouseDown(object sender, MouseEventArgs e)
        {
            if (selected != null) unSelect();
            else
            {
                picture.Image = null;
                picture.Left = e.X;
                picture.Top = e.Y;
                picture.Width = 0;
                picture.Height = 0;
                dodraw = true;
                picture.Visible = true;
                count = 0;
            }
        }
        public override void On_MouseMove(object sender, MouseEventArgs e)
        {

            if (dodraw&&count==5)
            {
                picture.Width = e.X - picture.Left;
                picture.Height = e.Y - picture.Top;
                picture.Invalidate();
                ((PictureBox)sender).Invalidate();
                count = 0;
            }
            count++;
        }
        public override void On_MouseUp(object sender, MouseEventArgs e)
        {
            if (dodraw)
            {
                dodraw = false;
                picture.Width = e.X - picture.Left;
                picture.Height = e.Y - picture.Top;
                if (picture.Width > 10 && picture.Height > 10) Save();
            }
        }
         
        public void picture_MouseDown(object sender, MouseEventArgs e)
        {
            dodrdr = true;
            X = e.X;
            Y = e.Y;
            count = 0;
            picture.Invalidate();
        }
        public void picture_MouseMove(object sender, MouseEventArgs e)
        {
            if (dodrdr)
            {
                if (count == 3)
                {
                    PictureBox pictureBox1 = (PictureBox)((PictureBox)sender).Parent;
                   
                    if (picture.Left + e.X - X>=0 && picture.Right + e.X - X <= pictureBox1.Width)
                    picture.Left += e.X - X;
                    if (picture.Top + e.Y - Y >=0 && picture.Bottom + e.Y - Y <= pictureBox1.Height)
                    picture.Top += e.Y - Y;
                    pictureBox1.Invalidate();
                    picture.Invalidate();
                    count=0;
                }
                count++;
                
                

            }
        }
        public void picture_MouseUp(object sender, MouseEventArgs e)
        {
            dodrdr = false;
        }

      

        internal void Save()
        {
            selected = new Bitmap(picture.Width, picture.Height, Active.MainImage.PixelFormat);
            Graphics grfx = Graphics.FromImage(selected);
            grfx.DrawImage(Active.MainImage, 0, 0, new Rectangle(picture.Left, picture.Top, picture.Width, picture.Height), GraphicsUnit.Pixel);
            picture.Image = selected;
            grfx.Dispose();

        }
        internal void unSelect()
        {
            if (Active.paste)
            {
                Bitmap temp = new Bitmap(selected);
                Save();
                CShapeMemento memento = this.createShapeMemento();
                Active.history.Push(memento);
                Graphics grfx = Graphics.FromImage(Active.MainImage);
                grfx.DrawImage(temp,picture.Left,picture.Top);
                grfx.Dispose();
                Active.paste = false;
            }
            picture.Left = 0;
            picture.Top = 0;
            picture.Visible = false;
            selected = null;
        }

    
        public void cut()
        {
            Clipboard.SetImage(selected);
            CShapeMemento memento = Active.selection.createShapeMemento();
            Active.history.Push(memento);
            Graphics grfx = Graphics.FromImage(Active.MainImage);
            grfx.FillRectangle(Brushes.White, picture.Left, picture.Top, picture.Width, picture.Height);
            Active.picture.Image = Active.MainImage;
            Active.selection.unSelect();
            grfx.Dispose();
        }
        public void paste()
        {
            selected = ((Bitmap)Clipboard.GetImage());
            picture.Left = 0;
            picture.Top = 0;
            picture.Width = selected.Width;
            picture.Height = selected.Height;
            picture.Image = selected;
            picture.Visible = true;
            Active.paste = true;
        }
        public void copy()
        {
            Clipboard.SetImage(selected);
        }

        public void delete()
        {
            CShapeMemento memento = Active.selection.createShapeMemento();
            Active.history.Push(memento);
            Graphics grfx = Graphics.FromImage(Active.MainImage);
            grfx.FillRectangle(Brushes.White,picture.Left,picture.Top,picture.Width,picture.Height);
            unSelect();
        }

    }
}
