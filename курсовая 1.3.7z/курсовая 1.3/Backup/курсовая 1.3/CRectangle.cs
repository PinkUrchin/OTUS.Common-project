﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace курсовая_1._3
{
    class CRectangle : CShape
    {
        private int _x1, _y1, _x2, _y2;
        int bigX, bigY, smallX, smallY;
        private bool dodraw;
        private bool _Ifiil;
        public CRectangle(bool Ifill)
        {
            _Ifiil = Ifill;
            _x1 = 0;
            _x2 = 0;
            _y1 = 0;
            _y2 = 0;
            int bigX = 0;
            int bigY = 0;
            int smallX = 0;
            int smallY = 0;
            
        }
        #region обработчики событий мыши
        public override void On_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                dodraw = true;
                _x1 = e.X;
                _y1 = e.Y;
                count = 0;

            }

        }
        public override void On_MouseMove(object sender, MouseEventArgs e)
        {
          
           Graphics grfx1 = ((PictureBox)sender).CreateGraphics();
           
            _x2 = e.X;
            _y2 = e.Y;
            if (dodraw&&count==5)
            {
                ((PictureBox)sender).Refresh();
                if (_x1 < _x2 && _y1 > _y2) { smallX = _x1; smallY = _y2; bigX = _x2; bigY = _y1; }
                if (_x1 > _x2 && _y1 < _y2) { smallX = _x2; smallY = _y1; bigX = _x1; bigY = _y2; }
                if (_x1 > _x2 && _y1 > _y2) { smallX = _x2; smallY = _y2; bigX = _x1; bigY = _y1; }
                if (_x1 < _x2 && _y1 < _y2) { smallX = _x1; smallY = _y1; bigX = _x2; bigY = _y2; }
                count = 0;
                if (_Ifiil)
                {
                    SolidBrush brush = new SolidBrush(Active.color);
                    grfx1.FillRectangle(brush, smallX, smallY, bigX - smallX, bigY - smallY);
                    brush.Dispose();
                }
                else grfx1.DrawRectangle(Active.pen, smallX, smallY, bigX - smallX, bigY - smallY);
            }
            count++;
            grfx1.Dispose();
        }
        public override void On_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                dodraw = false;
                if (_x1 < _x2 && _y1 > _y2) { smallX = _x1; smallY = _y2; bigX = _x2; bigY = _y1; }
                if (_x1 > _x2 && _y1 < _y2) { smallX = _x2; smallY = _y1; bigX = _x1; bigY = _y2; }
                if (_x1 > _x2 && _y1 > _y2) { smallX = _x2; smallY = _y2; bigX = _x1; bigY = _y1; }
                if (_x1 < _x2 && _y1 < _y2) { smallX = _x1; smallY = _y1; bigX = _x2; bigY = _y2; }
                CShapeMemento memento= this.createShapeMemento();
                Active.history.Push(memento);
                Graphics grfx1 = Graphics.FromImage(Active.MainImage);
                if (_Ifiil)
                {
                    SolidBrush brush = new SolidBrush(Active.color);
                    grfx1.FillRectangle(brush, smallX, smallY, bigX - smallX, bigY - smallY);
                    brush.Dispose();
                }
                else grfx1.DrawRectangle(Active.pen, smallX, smallY, bigX - smallX, bigY - smallY);
                ((PictureBox)sender).Image = Active.MainImage;
                grfx1.Dispose();
            }

        }
        

      
        #endregion

        public override CShapeMemento createShapeMemento()
        {
            ConcretMemento memento = new ConcretMemento();
            ConcretState state = new ConcretState();
            int dl = Convert.ToInt32(Active.pen.Width);
            state.maxX = bigX+5;
            state.maxY = bigY+5;
            state.minX = smallX-5;
            state.minY = smallY-5;
            state.name = "Rectangle";
            state.bitmap = new Bitmap(state.maxX-state.minX, state.maxY-state.minY);
            Graphics grfx = Graphics.FromImage(state.bitmap);
            grfx.DrawImage(Active.MainImage, 0, 0, new Rectangle(state.minX, state.minY, state.maxX - state.minX, state.maxY - state.minY), GraphicsUnit.Pixel);
            memento.setState(state);
            grfx.Dispose();
            return memento;
        }
       
    }
   
   
  
    

}
