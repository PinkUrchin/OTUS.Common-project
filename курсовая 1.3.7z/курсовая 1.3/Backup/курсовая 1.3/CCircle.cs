﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace курсовая_1._3
{
    class CCircle : CShape
    {
        private int _x1, _y1, _x2, _y2;
        private bool dodraw;
        private bool _Ifill;
        public CCircle(bool Ifill)
        {
            _Ifill = Ifill;
            _x1 = 0;
            _x2 = 0;
            _y1 = 0;
            _y2 = 0;
        }


        public override CShapeMemento createShapeMemento()
        {
            CShapeMemento memento=new ConcretMemento();
            ConcretState state=new ConcretState();
            if (_x1 < _x2 && _y1 > _y2) { state.minX = _x1-5; state.minY = _y2-5;  state.maxX = _x2+5; state.maxY = _y1+5; }
            if (_x1 > _x2 && _y1 < _y2) { state.minX = _x2-5; state.minY = _y1-5; state.maxX = _x1+5; state.maxY = _y2+5; }
            if (_x1 > _x2 && _y1 > _y2) { state.minX = _x2-5; state.minY = _y2-5; state.maxX = _x1+5; state.maxY = _y1+5; }
            if (_x1 < _x2 && _y1 < _y2) { state.minX = _x1-5; state.minY = _y1-5; state.maxX = _x2+5; state.maxY = _y2+5; }
            state.bitmap=new Bitmap(state.maxX-state.minX, state.maxY-state.minY);
            state.name = "Circle";
            Graphics grfx = Graphics.FromImage(state.bitmap);
            grfx.DrawImage(Active.MainImage,0,0,new Rectangle(state.minX,state.minY,state.maxX-state.minX,state.maxY-state.minY), GraphicsUnit.Pixel);
            memento.setState(state);
            grfx.Dispose();
            return memento;
        }
        
        #region обработчики событи   мыши
        public override void On_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                dodraw = true;
                _x1 = e.X;
                _y1 = e.Y;
                count = 0;


            }
        }
        public override void On_MouseMove(object sender, MouseEventArgs e)
        {

            if (dodraw&&count==3)
            {
                ((PictureBox)sender).Refresh();
                Graphics grfx1 = ((PictureBox)sender).CreateGraphics();
                if (_Ifill)
                {
                    SolidBrush brush = new SolidBrush(Active.color);
                    grfx1.FillEllipse(brush, _x1, _y1, e.X - _x1, e.Y - _y1);
                    brush.Dispose();
                }
                else grfx1.DrawEllipse(Active.pen, _x1, _y1, e.X - _x1, e.Y - _y1);
                grfx1.Dispose();
                count = 0;
            }
            count++;
            

        }
        public override void On_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                dodraw = false;
                _x2 = e.X;
                _y2 = e.Y;
                CShapeMemento memento = this.createShapeMemento();
                Active.history.Push(memento);
                Graphics grfx1 = Graphics.FromImage(Active.MainImage);
                if (_Ifill)
                {
                    SolidBrush brush = new SolidBrush(Active.color);
                    grfx1.FillEllipse(brush, _x1, _y1, _x2 - _x1, _y2 - _y1);
                    brush.Dispose();
                }
                else grfx1.DrawEllipse(Active.pen, _x1, _y1, _x2 - _x1, _y2 - _y1);
                grfx1.Dispose();
                ((PictureBox)sender).Image = Active.MainImage;

            }
        }
      
        #endregion

    }
}
